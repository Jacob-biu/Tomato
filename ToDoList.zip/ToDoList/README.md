# Doit 
基于 Android 时间管理App--待办事项提醒，番茄时钟

## App截图
![登录](https://github.com/LeeLulin/ToDoList/blob/master/pic/device-2018-09-27-200612.png)
![主界面](https://github.com/LeeLulin/ToDoList/blob/master/pic/device-2018-09-27-201432.png)
![新建待办](https://github.com/LeeLulin/ToDoList/blob/master/pic/device-2018-09-28-190951.png)
![番茄时钟](https://github.com/LeeLulin/ToDoList/blob/master/pic/device-2018-09-27-201607.png)

## Bmob云数据库结构
![Bmob](https://github.com/LeeLulin/ToDoList/blob/master/pic/Bomb.png)